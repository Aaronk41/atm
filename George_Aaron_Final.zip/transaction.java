		import java.util.Scanner;
		public class transaction {
	    public static void main(String args[] )  
	    	{  
	    	
	        double balance = 3000, withdraw, deposit;  
	          
	        
	        Scanner sc = new Scanner(System.in);  
	          
	        while(true)  
	        {  
	            System.out.println("Welcome to the Maze Bank ATM");  
	            System.out.println(""); 
	            System.out.print("Please choose one of the following:");  
	            System.out.println(""); 
	            System.out.println("Select 1 for Check Balance");  
	            System.out.println("Select 2 for Withdraw");  
	            System.out.println("Select 3 for Deposit");  
	            System.out.println("Select 4 for Exit");  
	      

	            
	            int choice = sc.nextInt();  
	            switch(choice)  
	            {  
	                case 1:  //check user balance//

				        System.out.println("Balance : "+balance);  
				        System.out.println("");  
				        System.out.println(""); 
				        break;  
	   
	                case 2:  //withdraw money from account//
	                	
	                	 System.out.print("Enter money to be withdrawn:");  
					        withdraw = sc.nextDouble();
					        
					        if(balance >= withdraw)  
					        {  
					            balance = balance - withdraw;  
					            System.out.println("Transation is complete"); 
					            System.out.println("Remaining Balance : "+balance);
					            }
					      
					    	
					        
					        else  
					        {    
					            System.out.println("Insufficient Funds");}  
					        System.out.println("");  
					        System.out.println(""); 
					        break;  
					      
	                case 3:  //deposit money from account//
	                	System.out.print("Enter money to be deposited:");   
				        deposit = sc.nextDouble();  
				        balance = balance + deposit;  
				        System.out.println("Transation is completed");  
				        System.out.println("Remaining Balance : "+balance);  
				        System.out.println("");  
				        System.out.println(""); 
				        break;  
	                	
	                case 4:  //exit program//
	       
	                	System.exit(0);  
	            }  
	        }  
	    }  
	}  